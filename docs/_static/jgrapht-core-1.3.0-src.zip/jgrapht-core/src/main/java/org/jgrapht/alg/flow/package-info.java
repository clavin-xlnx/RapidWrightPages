/**
 * Flow related algorithms.
 */
package org.jgrapht.alg.flow;

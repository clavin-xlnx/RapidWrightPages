/**
 * Algorithms for computing lowest common ancestors in graphs.
 */
package org.jgrapht.alg.lca;

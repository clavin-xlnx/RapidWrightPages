/**
 * Algorithms for <a href="http://mathworld.wolfram.com/IndependentVertexSet.html">Independent
 * Set</a> in a graph.
 */
package org.jgrapht.alg.independentset;
